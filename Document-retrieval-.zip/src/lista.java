/***
 * clasa care implementeaza crearea liste de indici
 * @author dorinela
 *
 */

class lista 
{
	
	String val;
	lista next;
	
	/***
	 * Constructor pentru lista
	 */
	public lista(){
		next = null;
	}

/***
 * adauga primul element in lista
 * @param v
 */
	public void adaugare(String v){ 
		lista l = new lista();
		l.val = v;
		next = l;
	}
	
	
	/***
	 * Adauga elemente in lista
	 * @param v
	 */

	public void adaugare_sfarsit(String v)
	{
		lista nou = new lista();
		nou.val = v;
		if(next==null)
			adaugare(v);
		else{
			lista p = next;
			while(p.next!=null){
				p=p.next;
			}
			p.next = nou;
		}
	}

	/***
	 * afisaza lista
	 */

	public String toString()
	{
		String aux = "[";
		lista p = next;
		while(p!=null){
			if(p.val.equals("")==false)
				aux = aux + p.val+",";
			p=p.next;
		}
		aux = aux+"\b]";
		return aux;
	
	}
	
	/***
	 * 
	 * @param index
	 * @return valoarea din lista aflata pe pozitia index
	 */

	public String getData(int index)
	{
		String val="";
		lista p = next;
		for(int i=0;i<=index;i++)
		{
			val = p.val;
			p=p.next;
		}
		return val;
	}
	
/***
 * 
 * @return numarul de elemente din lista
 */

	public int size()
	{
		lista p = next;
		int size = 1;
		if(next == null){
			return 0;
		}
		else{
			while(p.next!=null){
				size++;
				p=p.next;
			}
		return size;
		}
	}
	
	/***
	 * cauta o valoare in lista
	 * @param val
	 * @return false daca nu gaseste valoarea cautata si true daca gaseste valoarea cautata
	 */

	public boolean cautare(String val)
	{
		boolean a = false;
		lista p = next;
		while(p!=null){
			if(val.equals(p.val))
			{
				a = true;
				break;
			}
			else
				a = false;
			p=p.next;
		}
		return a;
	}
}
	
	
