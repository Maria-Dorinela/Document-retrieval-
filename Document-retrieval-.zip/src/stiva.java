/***
 * clasa care contine implementarea stivei
 * @author dorinela
 *
 * @param <Z>
 */

class stiva<Z> 
{
	Z val;
	stiva<Z> back,varf;
	public stiva(){
		back=null;
	}
	
	/***
	 * initializarea stivei
	 * @param v
	 */

	public void initializare(Z v)
	{
		varf = new stiva<Z>();
		varf.val=v;
		varf.back=null;
	}
	
	/***
	 * pune un element in varful stivei
	 * @param v
	 */

	public void push(Z v)
	{
		if(varf==null) 
			initializare(v);
		else
		{
			stiva<Z> s = new stiva<Z>();
			s.val = v;
			s.back=varf;
			varf = s;
		}
	}
	
	
	/***
	 * 
	 * @return elementul din varful stivei
	 */

	public Z pop(){
		stiva<Z> s = varf;
		varf=s.back;
		return s.val;
	}
	
	/***
	 *  verifica daca stiva e goala
	 * @return 1 daca stiva e goala si 0 daca stiva nu e goala
	 */

	public int empty()
	{
		if(varf == null)
			return 1;
		else 
			return 0;
	}
	
	
	/***
	 * 
	 * @return numarul de elemente din stiva
	 */

	public int size()
	{
		int nr_elemente=0;
		if(empty()==1)
			return 0;
		else
		{
			stiva<Z> s = varf;
			while(s!=null)
			{
				s=s.back;
				nr_elemente++;
			}
			return nr_elemente;
		}
	}
}
