import java.util.Scanner;
/***
 *  clasa care contine structura arborelui in care introduc expresiile
 * @author dorinela
 *
 */

public class Node_EX 
{
	
	public Node_EX left, right;
	public String key;
	/***
	 * Constructor care initializeaza left si right cu null, adica arborele nu contine noduri stanga respectiv dreapta
	 */
	public Node_EX(){
		left = null;
		right =null;
	}
}
