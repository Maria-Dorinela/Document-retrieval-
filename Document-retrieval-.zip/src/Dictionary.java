import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;
/***
 * clasa ce defineste tipul dictionar
 * @author dorinela
 *
 */
public class Dictionary { 
	 
	public int numEntries = 0;
	public Hashtbl hashtbl;
	/***
	 *  Constructor pentru dictionar. Primeste ca parametru numele fisierului text (dictionarului) si il citeste linie cu linie
	 * @param inputFile
	 * numele fisierului text
	 */
	
	public Dictionary(String inputFile){
		try      
		{
			File dictFile = new File(inputFile);
			Scanner reader = new Scanner(dictFile);
			@SuppressWarnings("unused")
			String line;
			while (reader.hasNextLine())
			{
				numEntries++;
				line = reader.nextLine();
			}
			reader.close();
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}
		String chei[] = new String[numEntries]; //vectorul de stringuri care contine cuvintele din dictionar
		hashtbl = new Hashtbl(numEntries); 
		try
		{
			File dictFile = new File(inputFile);
			Scanner reader = new Scanner(dictFile);
			String strLine;	
			String v[]; 
			int k=0;
			
			//citesc linie cu linie din fisier
			
			while (reader.hasNextLine()) {
				lista valori = new lista();
				strLine = reader.nextLine(); 
				int size = strLine.split(" ").length;
				v = new String[size];  //folosesc vectorul v in care introduc pentru fiecare linie din dictionar cuvantul si indicii
				StringTokenizer st = new StringTokenizer(strLine, " ");
				int i=0;
				while (st.hasMoreTokens()) 
				{
			    	v[i] = st.nextToken();
			    	i++;
			    }
				chei[k] = v[0];        //primul element din vectorul v reprezinta cuvantul (cheia) pe care il introduc in alt vector "chei"
			    for(int j=1;j<v.length;j++)  //restul elementelor din vector (indici) ii introduc intr-o lista "valori"
			    {
			    	valori.adaugare_sfarsit(v[j]);
			    }
			    hashtbl.insert(v[0],valori);  //pentru cuvantul din dictionar ii atribui lista cu indicii corespunzatori,
			                                    // adica fac o legatura intre cheie si lista
			    k++;
			}
			reader.close();
			
			
		}catch (Exception e) 
		{
			System.err.println("Error: " + e.getMessage());
		}
	}
	/***
	 * 
	 * @return numarul de intrari in dictionar
	 */
	public int getnumEntries() 
	{
		return numEntries;
	}
}


