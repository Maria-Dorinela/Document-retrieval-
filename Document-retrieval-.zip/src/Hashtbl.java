/***
 * clasa care face legarura intre cuvant (cheie) si lista cu indici 
 * @author dorinela
 *
 */
public class Hashtbl {
	
    public Hashnode[] nodes;
    /***
     * Constructor pentru Hashtbl
     * @param size
     */
    
    public Hashtbl(int size)
    {
        nodes = new Hashnode[size];
    }

    /***
     * 
     * @param key
     * @return indexul cheii
     */
    public int getIndex(String key)
	{
	    int hash = key.hashCode() % nodes.length;
	    if (hash < 0)
	        hash += nodes.length;
	    return hash;
	}
    
    
    /***
     * metoda ce insereaza la cheia key lista cu indici
     * @param key
     * @param data
     * @return 
     */
    public lista insert(String key, lista data)
    {
        int hash = getIndex(key);
       
        for (Hashnode node = nodes[hash]; node != null; node = node.next) {
            if (key.equals(node.key)) {
                lista oldData = node.data;
                node.data = data;
                return oldData;
            }
        }
 
        Hashnode node = new Hashnode(key, data, nodes[hash]);
        nodes[hash] = node;
        return null;

    }
    
    /***
     * 
     * @param key
     * @return lista cu indici cuvantului din dictionar dat ca parametru
     */

    
    public lista get(String key)
    {
        int hash = getIndex(key);

        for (Hashnode node = nodes[hash]; node != null; node = node.next) {
            if (key.equals(node.key))
                return node.data;
    }

        return null;
    }
}

