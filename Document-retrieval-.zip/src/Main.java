import java.util.Scanner;
/***
 * Clasa Main
 * @author dorinela
 *
 */
public class Main {

	static Dictionary d;
	static int i;
	private static Scanner scanner;
	private static String[] input;

	/***
	 * Metoda main 
	 * @param args
	 * Argumentele primite de program
	 */
	public static void main(String[] args) {
		d = new Dictionary(args[0]);
		
		
		scanner = new Scanner(System.in); String str = scanner.nextLine(); 
		 while(str.equals("exit")==false) {
		 
		 String r1,r2; 
		 String s = addSpace(str); 
		 r1 = toPrefix(s); 
		 r2 = keyToList(r1); 
		 
		 lista rezultat = new lista();
		 
		
		 input = r2.split(" "); 
		 Node_EX nod = new Node_EX(); 
		 i = input.length - 1; 
		 citire(nod); 
		 
		 rezultat = evaluate(nod);  
		
		 String output = Output(rezultat); 
		 System.out.println(output);
		 
		
		 str = scanner.nextLine(); }
		 
	}
	
	/***
	 * metoda care adauga spatiu dupa paranteza deschisa si pana in paranteza inchisa
	 *  Aceasta deoarece expresia data ca input nu are spatiu la paranteze iar eu cand transform in prefix imi trebuie spatiu
	 * @param s
	 * @return rezultat = stringul dat ca parametru cu spatii la paranteze
	 */
	
		public static String addSpace(String s) {
			String rezultat = "";
			String rezultat_v[] = new String[s.split("").length];

			String s_v[] = s.split("");
			for (int i = 0; i < s_v.length; i++) {
				if (s_v[i].equals("(")) {
					rezultat_v[i] = "( ";
				} else if (s_v[i].equals(")")) {
					rezultat_v[i] = " )";
				} else {
					rezultat_v[i] = s_v[i];
				}
			}

			for (int i = 0; i < rezultat_v.length; i++) {
				rezultat += rezultat_v[i];
			}
			return rezultat;

		}
		
		/***
		 * metoda care transform expresia din infix(=asa cum e ea data cu paranteze) in prefix(=fara paranteze) pentru a introduce in arbore
		 * in arbore introduc expresia transformata in prefix
		 * @param s
		 * @return Stringul transformat in prefix
		 */
			
			public static String toPrefix(String s) {
				stiva<String> stiva = new stiva<String>(); //pentru a transforma expresia in prefix folosesc o stiva
				
				String[] v = s.split(" ");  //despart stringul s si introduc datele in vectorul v
				
				String rezultat = "";  //in rezultat introduc expresia transformata in prefix
				String rezultat_fals="";
				
				
				for (int i=v.length-1; i>=0; i--){  //parcurg vectorul de la coada la cap
					if(v[i].equals(")"))           // daca elementul din vector e ")" introduc acest element in stiva
					{
						stiva.push(v[i]);
					}
					
					else if(v[i].equals("and") || v[i].equals("or"))   //Daca elementul din vector e unul din operatori introduc acest element tot in stiva
					{
						stiva.push(v[i]);
					}
					
					else if(v[i].equals("(")){    //daca elementul din vector e "(" ma duc la stiva si golesc elementele din stiva in rezultat---
						while(stiva.size()>0)     //-----pana cand intalnesc ")", si elimin "("
						{
							String aux = stiva.pop();
							if(aux.equals(")")){
								//rezultat_fals+=aux;
								break;
							}
							if(aux.equals("("))
							{
								rezultat_fals+=aux;  // in rezultat_fals introduc "(" pentru ca trebuie eliminat
							}
							else
							{
								rezultat += aux; //daca in stiva am operatori ii introduc in rezultat
								rezultat += " ";
							}
						}
					}
					else
					{
						rezultat+=v[i];  //daca in vector am cuvinte le introduc in rezultat
						rezultat+=" ";
					}
				}
				
				//la sfarsit golesc tot din stiva in rezultat cu exceptia parantezelor
				while (stiva.size() > 0)
				{
					String a = stiva.pop();
					if(a.equals("(") ==  false && a.equals(")") == false)
				    rezultat += stiva.pop();
				}
				
				return rezultat; // returnez rezultat
				//expresia in prefix este "rezultat" dar citit invers de la coada la cap dar eu aici in functie il  las asa iar cand creez arborele parcurg invers
			}

/***
 * la expresia deja transformata in prefix asociez cuvintelor listele cu indici corespunzatori
 * @param s
 * @return String in care cuvintele sunt inlocuite de lista cu indici corespunzatoare
 */


	
	public static String keyToList(String s) {
		String rezultat = "";
		String[] s_v = s.split(" ");
		for (int i = 0; i < s_v.length; i++) {
			if (s_v[i].equals("(") || s_v[i].equals(")")) {
				s_v[i] += " ";
			} else if (s_v[i].equals("and")) {
				s_v[i] = "and";
				s_v[i] += " ";
			} else if (s_v[i].equals("or")) {
				s_v[i] = "or";
				s_v[i] += " ";
			} else {
				lista l = new lista();
				l = d.hashtbl.get(s_v[i]);
				if (l != null) {
					s_v[i] = l.toString();
					s_v[i] += " ";
				} else {
					s_v[i] = "[,]";
					s_v[i] += " ";
				}
			}
		}
		for (int i = 0; i < s_v.length; i++)
			rezultat += s_v[i];
		return rezultat;
	}
	
	/***
	 * metoda recursiva care creaza arborele cu expresii
	 * @param p
	 */
	
	
		public static void citire(Node_EX p) {
			p.key = input[i];
			
			if (input[i].equals("and") || input[i].equals("or")) {
				p.left = new Node_EX();
				i--;
				citire(p.left);

				p.right = new Node_EX();
				i--;
				citire(p.right);
			}

		}
		
/***
 * metoda care parcurge arborele si calculeaza expresia
 * @param _node
 * @return
 */
	

	private static lista evaluate(Node_EX _node) {
		if (_node.left == null || _node.right == null) {
			return toList(_node.key);
		}
		String op = _node.key;
		if (op.equals("and") == true) {
			return and(evaluate(_node.left), evaluate(_node.right));
		} else {
			return orr(evaluate(_node.left), evaluate(_node.right));
		}

	}
	
	/***
	 * metodele mele de reuniune si intersectie returneaza o lista, ceea ce nu e la fel cu output-ul cerut 
	 * pentru aceasta transform lista intr-un vector de stringuri
	 * @param l
	 * @return lista cu output-ul transformata in string
	 */
	
		public static String Output(lista l){
			String rezultat = "";
			for(int i=0; i<l.size(); i++)
			{
				rezultat += l.getData(i);
				rezultat += " ";
			}
			return rezultat;
		}

	
		/***
		 * metoda care face intersectia intre 2 liste cu indici
		 * @param li1
		 * @param li2
		 * @return O lista cu elementele comune celor 2 liste date ca parametru
		 */

	public static lista and(lista li1, lista li2) {
		lista rezultat = new lista();
		for (int i = 0; i < li1.size(); i++) {
			for (int j = 0; j < li2.size(); j++) {
				if (li1.getData(i).equals(li2.getData(j))) {
					rezultat.adaugare_sfarsit(li1.getData(i));
				}
			}
		}
		return rezultat;
	}
	/***
	 * metoda care face reuniunea intre 2 liste date ca parametri
	 * @param li1
	 * @param li2
	 * @return O lista cu reuniunea elementelor celor 2 liste
	 */
	
 
	public static lista orr(lista li1, lista li2) {
		lista rezultat;
		rezultat = li1;
		for (int i = 0; i < li2.size(); i++) {
			if (li1.cautare(li2.getData(i)) == false) {
				rezultat.adaugare_sfarsit(li2.getData(i));
			}
		}
		return rezultat;

	}

	/***
	 * transforma un string intr-o lista
	 * @param str
	 * @return lista
	 */


	public static lista toList(String str) {
		lista rezultat = new lista();
		str = str.substring(1, str.length() - 2);
		String[] str_arr = str.split(",");
		for (int i = 0; i < str_arr.length; i++) {
			rezultat.adaugare_sfarsit(str_arr[i]);
		}
		return rezultat;
	}
	



}
