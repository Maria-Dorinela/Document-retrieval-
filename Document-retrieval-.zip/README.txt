TEMA_1--Sirbu Maria-Dorinela, 325CB

Pentru rezolvarea acestei teme am folosit clasele:
-Main;
-Dictionary;
-Hashnode;
-Hashtbl;
-lista;
-Node_EX;
-stiva.

Clasa Hashnode:

-contine un string care reprezinta cuvantul din dictionar, o lista in care se afla
indici cuvantului respectiv si un "next" de tipul Hashnode;
-aceasta clasa reprezinta structura mea in care introduc dictionarul;
-structura mea e de tipul: un vector de stringuri in care introduc cuvintele din dictionar(chei),
iar fiecare element din acest vector indica catre o lista in care se afla indici cuvantului respectiv;


Clasa Hashtbl:

-in aceasta clasa asociez fiecariu cuvant din dictionar lista cu indici corespunzatori
-am o metoda "get" care returneaza lista cuvantului dat ca parametru;

Clasa Node_EX:

-in aceasta clasa am structura arborelui pe care il folosesc pentru calculul expresiilor;

Clasa stiva:

-in aceasta clasa am implementare pentru o stiva;
-stiva o folosesc pentru a transforma expresia din infix( forma ei data ca input) in prefix.
-cu ajutorul expresiei in forma prefix creez arborele cu expresia recursiv;
-am explicat in cod cum transform din infix in prefix;
-clasa stiva contine metodele: push, pop, size, empty,initializare specifice unei stive;


Clasa lista:

-in aceasta clasa am implementarea pentru o lista cu metodele:
adaugare_sfarsit, toString, getData, size, cautare.In cod scrie la fiecare ce anume fac.


Clasa Dictionary:

-in aceasta clasa citesc din fisier linie cu linie;
-despart linia si introduc stringurile intr-un vector;
-din vectorul obtinut primul element reprezinta "cheia" pe care o introduc intr-un vector de stringuri,
iar restul elementelor le introduc intr-o lista (lista cu indici);
-metoda getnumEntries returneaza numarul de linii din dictionar;

Clasa Main:

In aceasta clasa se gasesc metodele:
-addSpace - adauga spatiu la expresia primita ca input dupa parantezele deschise si inainte de cele inchise;
Aceasta deoarece in urmatoarea metoda in care transform din infix in prefix imi trebuie expresia cu spatii.
-toPrefix - transforma expresia din infix in prefix;
-keyList - la expresia transformata in prefix pune in locul cheilor lista cu indicii corespunzatori;
-citire - introduce expresia in arbore;
-evaluate - calculeaza expresia, returneaza o lista;
-Output - transforma lista rezultat(calculul expresiei) intr-un string;
-and - face intersectia intre 2 liste primite ca parametru;
-orr - face reuniunea intre 2 liste primite ca parametru;


Am povestit pe scurt cum rezolv aceasta tema, in cod se gasesc explicatii la metode.
Sper ca am fost destul de clara in README cu privire la rezolvarea temei.










